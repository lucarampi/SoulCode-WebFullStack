n1 = 3
n2 = 1
n3 = 4
n4 = 5

temp = 0


n1 = parseInt(prompt("Digite um numero:"))
n2 = parseInt(prompt("Digite um numero:"))
n3 = parseInt(prompt("Digite um numero:"))
n4 = parseInt(prompt("Digite um numero:"))

if (n1 < n2 & n2 < n3) { // sabemos q n1 é o menor numero
    if (n2 < n3 & n3 < n4) {// Ordem: n1 n2 n3 n4
        document.write(`Ordem crescente: ${n1} , ${n2} , ${n3} , ${n4}`)

    } else if (n2 < n4 & n4 < n3) {// Ordem: n1 n2 n4 n3
        document.write(`Ordem crescente: ${n1} , ${n2} , ${n4} , ${n3}`)

    } else if (n3 < n2 & n2 < n4) {// Ordem: n1 n3 n2 n4
        document.write(`Ordem crescente: ${n1} , ${n3} , ${n2} , ${n4}`)

    } else if (n3 < n4 & n4 < n2) {// Ordem: n1 n3 n4 n2
        document.write(`Ordem crescente: ${n1} , ${n3} , ${n4} , ${n2}`)

    } else if (n4 < n2 & n2 < n3) {// Ordem: n1 n4 n2 n3
        document.write(`Ordem crescente: ${n1} , ${n4} , ${n2} , ${n3}`)

    } else { // Ordem: n1 n4 n3 n2
        document.write(`Ordem crescente: ${n1} , ${n4} , ${n3} , ${n2}`)
    }

    if (n1 < n2 & n2 < n3) { // sabemos q n1 é o menor numero
        if (n2 < n3 & n3 < n4) {// Ordem: n1 n2 n3 n4
            document.write(`Ordem crescente: ${n1} , ${n2} , ${n3} , ${n4}`)

        } else if (n2 < n4 & n4 < n3) {// Ordem: n1 n2 n4 n3
            document.write(`Ordem crescente: ${n1} , ${n2} , ${n4} , ${n3}`)

        } else if (n3 < n2 & n2 < n4) {// Ordem: n1 n3 n2 n4
            document.write(`Ordem crescente: ${n1} , ${n3} , ${n2} , ${n4}`)

        } else if (n3 < n4 & n4 < n2) {// Ordem: n1 n3 n4 n2
            document.write(`Ordem crescente: ${n1} , ${n3} , ${n4} , ${n2}`)

        } else if (n4 < n2 & n2 < n3) {// Ordem: n1 n4 n2 n3
            document.write(`Ordem crescente: ${n1} , ${n4} , ${n2} , ${n3}`)

        } else { // Ordem: n1 n4 n3 n2
            document.write(`Ordem crescente: ${n1} , ${n4} , ${n3} , ${n2}`)
        }




// } else if (n1 < n3 & n3 < n2) {// sabemos q n1 é o maior numero









// } else if (n2 < n1 & n1 < n3) {// sabemos q n1 é o maior numero

// } else if (n2 < n3 & n3 < n1) {// sabemos q n1 é o maior numero

// } else if (n3 < n1 & n1 < n2) {// sabemos q n1 é o maior numero

// } else { //Quando n3<n2 & n2<n1

// }






// if (n1>n2 & n1>n3 & n1>n4) a1 = n1
// if (n2>n1 & n2>n3 & n2>n4) a1 = n2
// if (n3>n1 & n3>n2 & n3>n4) a1 = n3
// if (n4>n1 & n4>n2 & n4>n4) a1 = n4