var a = parseInt(prompt("Digite o numero do mês desejado: \n 1) Janeiro \n 2) Fevereiro \n 3) Março \n 4) Abril \n 5) Maio \n 6) Junho \n 7) Julho \n 8) Agosto \n 9) Setembro \n 10) Outubro \n 11) Novembro \n 12) Dezembro"))
switch (a) {
    case 0:
        alert("Zero")
        break;
    case 1:
        alert("Um")
        break;
    case 2:
        alert("Dois")
        break;
    case 3:
        alert("Três")
        break;
    case 4:
        alert("Quatro")
        break;
    case 5:
        alert("Cinco")
        break;
    case 6:
        alert("Seis")
        break;
    case 7:
        alert("Sete")
        break;
    case 8:
        alert("Oito")
        break;
    case 9:
        alert("Nove")
        break;
    case 10:
        alert("Dez")
        break;

    default:
        alert("Numero inválido! \n Recarregue a página e tente novamente.")
        break;
}