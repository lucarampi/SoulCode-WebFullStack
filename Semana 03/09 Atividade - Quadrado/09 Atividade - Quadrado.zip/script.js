a = 0
while (a<=100) {
    document.write(a**2, "<br>")
    a += 2
}

