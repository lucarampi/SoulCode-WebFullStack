const inteiro = 2
const real = 3
const my_string1 =  " Hello Word Java Script"
const my_string2 =  " Minha String 2"

document.write(`Meu numero inteiro é ${inteiro}.<br>`)
document.write(`Meu numero real é ${real}.<br>`)
document.write(`Minha string 1 é ${my_string1}.<br>`)
document.write(`Minha string 2 é ${my_string2}.<br>`)

alert("Atividade finalizada")












// Luca Alfaro Rampinelli