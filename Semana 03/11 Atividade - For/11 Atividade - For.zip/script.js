for (soma = 1; soma < 1000; soma++) {
    
}
alert(soma)