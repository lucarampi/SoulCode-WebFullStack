soma = 0
for (i = 1; i <= 1000; i++) {
    soma += i
}
alert(soma)