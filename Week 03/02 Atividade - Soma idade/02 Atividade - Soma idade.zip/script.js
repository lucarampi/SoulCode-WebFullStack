my_age = 21
son_age = 0
father_age = 63
sister_age = 17
income = 2000
members = 4

total1 = 0
document.write(total1 = my_age + son_age,"<br>")
document.write(total2 = total1*father_age,"<br>")
document.write(total3 = sister_age*my_age/total1,"<br>")
document.write(total4 = 30*income / members,"<br>")

document.write(`|| 1) ${total1} || 2) ${total2} || 3) ${total3} || 4) ${total4} ||` ,"<br>")