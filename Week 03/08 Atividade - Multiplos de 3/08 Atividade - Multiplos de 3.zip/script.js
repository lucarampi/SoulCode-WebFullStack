a = 0
while (a<100) {
    document.write(a, "<br>")
    a += 3
}

