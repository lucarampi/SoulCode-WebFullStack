$(function () {
  $("#tabs").tabs();
});

$(function () {
  $("#accordion").accordion();
});

